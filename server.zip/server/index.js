import express from "express";
import { registerAgentRoutes } from "./agents.js";

const app = express();
const port = Number(process.env.PORT || 5000);

app.use(express.json({ limit: "32kb" }));

registerAgentRoutes(app);

app.get("/health", (_request, response) => response.json({ status: "ok" }));

app.listen(port, () => {
  console.log(`Local analog design API listening on http://localhost:${port}`);
});
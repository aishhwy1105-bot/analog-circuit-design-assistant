function promptDetails(userPrompt) {
  const prompt = userPrompt.toLowerCase();
  const inputMatch = prompt.match(/(\d+(?:\.\d+)?)\s*v\s*(?:input|in|to)/i);
  const outputMatch = prompt.match(/(?:to|output|out)\s*(\d+(?:\.\d+)?)\s*v/i);
  const currentMatch = prompt.match(/(\d+(?:\.\d+)?)\s*a(?:mp)?/i);
  const inputVoltage = inputMatch?.[1] || "12";
  const outputVoltage = outputMatch?.[1] || "5";
  const current = currentMatch?.[1] || "2";
  const power = (Number(outputVoltage) * Number(current)).toFixed(1).replace(/\.0$/, "");
  const isolated = /isolat|flyback|offline|ac\s*dc/i.test(prompt);
  return {
    inputVoltage,
    outputVoltage,
    current,
    power,
    topology: isolated ? "Flyback" : "Synchronous buck converter",
  };
}

function createAskData(userPrompt) {
  const details = promptDetails(userPrompt);
  return {
    overview: `For a ${details.inputVoltage} V input to ${details.outputVoltage} V output at ${details.current} A, a ${details.topology.toLowerCase()} is technically feasible. Use a controlled switching loop, conservative current limits, and deliberate EMI filtering.`,
    recommended_topology: `${details.topology}: it provides an efficient regulated conversion path for the requested voltage and load, subject to transient, thermal, and isolation requirements.`,
    essential_components: [
      { category: "Controller / IC", recommendation: "Dedicated current-mode PWM controller with UVLO, soft-start, current limit, and feedback compensation." },
      { category: "Power Switches", recommendation: "N-channel MOSFET sized for the voltage transient and RMS current; use a GaN HEMT when switching loss and density justify it." },
      { category: "Magnetics", recommendation: `${details.topology === "Flyback" ? "High-frequency transformer" : "Shielded power inductor"} sized for ${details.power} W with controlled ripple and temperature rise.` },
      { category: "Passive Filtering", recommendation: "Low-ESR ceramic and polymer electrolytic capacitors with an input EMI filter and short high-di/dt loop." },
    ],
    estimated_budget: {
      prototype_bom_usd: "$15 - $25",
      production_1k_usd: "$4 - $7",
      notes: "Cost variance driven by silicon vs. GaN choices and magnetics customization.",
    },
    thermal_and_safety_considerations: [
      "Thermal: Target maximum junction temperature < 105°C.",
      "Safety: Use reinforced galvanic isolation meeting IEC 62368-1 where the application requires isolation.",
      "EMI: Use common-mode filtering and appropriate X/Y safety filtering at an AC/DC inlet.",
    ],
  };
}

function createPlanData(userPrompt, tier = "standard") {
  const details = promptDetails(userPrompt);
  const tiers = {
    economical: {
      target_cost: "Low-cost baseline",
      topology: details.topology,
      efficiency_target: ">88%",
      key_parts: ["Integrated PWM controller", "Silicon MOSFET", "Ferrite inductor"],
      pcb_constraints: "2-layer standard FR4, basic heatsinks",
    },
    standard: {
      target_cost: "Balanced industry standard",
      topology: details.topology,
      efficiency_target: ">92%",
      key_parts: ["Synchronous PWM controller", "Low-Qg MOSFET pair", "Shielded power inductor"],
      pcb_constraints: "2-4 layer PCB, optimized routing, GaN/Si hybrid",
    },
    premium: {
      target_cost: "High performance / compact",
      topology: details.topology === "Flyback" ? "Active Clamp Flyback" : "GaN synchronous buck",
      efficiency_target: ">94%",
      key_parts: ["Digital power controller", "GaN power switches", "Planar or custom shielded magnetics"],
      pcb_constraints: "4-layer HDI, integrated planar magnetics, GaN switches",
    },
  };
  const selectedTier = tiers[tier] ? tier : "standard";
  return {
    project_name: `${details.outputVoltage} V ${details.topology} Power Stage`,
    selected_tier: selectedTier,
    voltage_ratings: {
      vin_range: `${details.inputVoltage} V nominal, verify transients`,
      vout: `${details.outputVoltage} V`,
      power_rating: `${details.power} W at ${details.current} A`,
    },
    tiers,
    pcb_placement_roadmap: [
      "Input connector, fuse, reverse-polarity protection, and EMI filter at the board edge.",
      "Place the controller close to the gate-drive and current-sense loop.",
      "Keep the high-current switching loop compact with short, wide copper.",
      "Place output rectification, magnetics, capacitors, and feedback in the quiet return path.",
    ],
    critical_precautions: [
      "Maintain creepage and clearance for the maximum working voltage.",
      "Minimize gate-driver loop inductance and ringing.",
      "Separate power returns from analog feedback and validate thermal margins.",
    ],
  };
}

function requirePrompt(request, response) {
  if (typeof request.body?.user_prompt !== "string" || !request.body.user_prompt.trim()) {
    response.status(400).json({ mode: "error", status: "error", error: "user_prompt must be a non-empty string." });
    return null;
  }
  return request.body.user_prompt.trim();
}

export function registerAgentRoutes(app) {
  app.post("/api/copilot/ask", (request, response) => {
    const userPrompt = requirePrompt(request, response);
    if (!userPrompt) return;
    response.json({ mode: "ask", status: "success", data: createAskData(userPrompt) });
  });

  app.post("/api/copilot/plan", (request, response) => {
    const userPrompt = requirePrompt(request, response);
    if (!userPrompt) return;
    const tier = ["economical", "standard", "premium"].includes(request.body?.tier) ? request.body.tier : "standard";
    response.json({ mode: "plan", status: "success", data: createPlanData(userPrompt, tier) });
  });
}